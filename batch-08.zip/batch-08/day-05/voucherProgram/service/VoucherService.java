package voucherProgram.service;

import voucherProgram.dto.Product;
import voucherProgram.service.ProductService;

public class VoucherService{
	private ProductService service;
	
	public VoucherService(){
		service = new ProductService();
	}

	public void addProduct(Product p){
		service.saveProductToArray(p);
	}

	public Product[] getProducts(){
		return service.getProducts();
	}
}