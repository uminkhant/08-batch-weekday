package voucherProgram.service;

import voucherProgram.dto.Product;

public class ProductService{
	private Product[]products;
	{
		products = new Product[0];
	}

	public void saveProductToArray(Product p){
		Product[]temp = new Product[products.length+1];

		for(int i = 0 ; i < products.length ; i ++){
			temp[i] = products[i];
		}
		temp[products.length] = p ;
		products = temp;
	}

	public Product getProduct(int index){
		return products[index];
	}

	public Product[] getProducts(){
		return products;
	}
}