package voucherProgram.dto;

public class Product{
	private String name;
	private int price;
	private int qty;

	public Product(String name,int price){
		this.name = name ;
		this.price = price ;
	}
	public int getTotal(){
		return price*qty;
	}

	public void setQty(int qty){
		this.qty = qty;
	}
	public int getQty(){
		return qty;
	}

	public String getName(){
		return name;
	}

	public int getPrice(){
		return price;
	}


}