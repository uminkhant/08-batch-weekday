package voucherProgram;

import java.util.Scanner;
import voucherProgram.dto.Product;
import voucherProgram.service.*;

public class Main{
	private static Scanner sc;
	private static ProductService service;
	private static Product[]products;
	private static VoucherService vouService;

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		vouService = new VoucherService();
		service = new ProductService();
		greeting(" Welcome ");
		askProductAgain();
		selectProduct();
		showVoucher();
		greeting(" Exit Program ");
	}
	static void showVoucher(){
		Product[] arrays = vouService.getProducts();
		int total = 0 ;
		for(int i = 0 ; i < arrays.length ; i ++){
			Product p = arrays[i];
			total += p.getTotal();
			System.out.println((i+1)+"\t"+p.getName()+"\t"+p.getPrice()+"\t"+p.getQty()+"\t"+p.getTotal());			
		}
		System.out.println();
		System.out.println("\tTotal ::: "+total);

	}
	static void selectProduct(){
		showProduct();
		String yes = "";
		do{
			System.out.println("\tPlease select 1 product !");
			int num = sc.nextInt();
			System.out.println("\tPlease type qty !");
			int qty = sc.nextInt();
			Product  p = service.getProduct(num-1);
			p.setQty(qty);
			vouService.addProduct(p);
			System.out.println("\tDo you want to add product again y/other");
			yes = sc.next();
		}while("y".equalsIgnoreCase(yes));

	}
	static void showProduct(){
		Product[] products = service.getProducts();
		for(int i = 0 ; i < products.length ; i ++){
			Product p = products[i];
			System.out.println((i+1)+"\tName : "+p.getName()+
				"\tPrice : "+p.getPrice());
		}
	}
	static void askProductAgain(){
		String yes = "" ;
		do{
			Product p =	addProduct();
			service.saveProductToArray(p);
			System.out.println("\tDo you want to add product again y/other");
			yes = sc.next();

		}while("y".equalsIgnoreCase(yes));
		products = service.getProducts() ;
	}

	static Product addProduct(){
		System.out.println("\tType Product Name !");
		String name = sc.next();
		System.out.println("\tType Product Price !");
		int price = sc.nextInt();
		return new Product(name,price);
	}
	
	static void greeting(String message){
		System.out.println();
		System.out.println("  =======================================");
		System.out.println("================ "+message+" ===============");
		System.out.println(". =======================================");
		System.out.println();
	}
	
	






}