class Person{

	static String name;
	{
		System.out.println("Hello instance block");
	}
	static{
		System.out.println("Hello Static block");
	}

	Person(){
		System.out.println("Hello Constructor");
	}

	void setName(String name){
		this.name = name;
	}

	String getName(){
		return name;
	}

}
