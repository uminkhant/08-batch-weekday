class Main{
	public static void main(String[] args) {
		
		Person.name = "Sandar";
		// p.setName("Win Win");
		// String name = p.getName();
		// System.out.println(name);
	}

	 


}
