package testOne.pkgTwo;
public class Animal{
	public void chasing(){
		System.out.println("chasing");
	}
}