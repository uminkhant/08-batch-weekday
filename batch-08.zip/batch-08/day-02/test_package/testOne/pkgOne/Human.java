package testOne.pkgOne;
import testOne.pkgTwo.Animal;

public class Human{
	public void show(){
		//Animal a = new Animal();
		System.out.println("Showing somthing");
	}
}