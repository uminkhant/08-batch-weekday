package testOne.pkgOne;
public class Person{

	public static String name;
	public static void doSomething(){
		System.out.println("Do Something");
	}
}