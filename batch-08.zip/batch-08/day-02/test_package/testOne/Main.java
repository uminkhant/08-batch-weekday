package testOne;
import testOne.pkgOne.*;
import testOne.pkgTwo.Animal;

import static testOne.pkgOne.Person.doSomething;
import static testOne.pkgOne.Person.name;

class Main{

		public static void main(String[] args) {
		Human h = new Human();
		h.show();
		Animal a = new Animal();
		a.chasing();
		//Person p = new Person();
		doSomething();
		name = "sss";
		Main m = new Main();
		hide();
	}

	 void hide(){}
}