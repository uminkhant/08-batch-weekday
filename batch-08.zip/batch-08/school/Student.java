class Student{

	String name;
	int age;

	Student(){
		System.out.println("Without parameter");
	}
	Student(String n){
		System.out.println("with name");
	}
	Student(String n ,int a){
		System.out.println("with name and age !");
		name = n;
		age = a;
	}

	void setName(String name,String type){
		this.name = name;
	}
	void setAge(int age){
		this.age = age;
	}

	String getName(){
		return name;
	}
	int getAge(){
		return age;
	}

	void showDisplay(){
		setName("sss","Male");
		String s = getName();
		System.out.println("Student name is :"+s+ " and age is "+ getAge());
	}
}