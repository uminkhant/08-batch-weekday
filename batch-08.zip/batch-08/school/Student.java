class Student{

	String name;
	int age;

	Student(){
		System.out.println("Without parameter");
	}
	Student(String n){
		System.out.println("with name");
	}
	Student(String n ,int a){
		System.out.println("with name and age !");
		name = n;
		age = a;
	}

	void setName(String name){
		this.name = name;
	}
	void setAge(int age){
		this.age = age;
	}

	String getName(){
		return name;
	}
	int getAge(){
		return age;
	}

	void showDisplay(){
		System.out.println("Student name is :"+getName()+ " and age is "+ getAge());
	}
}