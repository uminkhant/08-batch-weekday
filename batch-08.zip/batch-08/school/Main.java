import java.util.Scanner;
class Main{

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please type name !");
		String name = sc.next();
		System.out.println("Please type age  !");
		int age = sc.nextInt();

		Student st = new Student(name,age);
		
		st.showDisplay();
		// st.setName(name);
		// st.setAge(age);

	}
}