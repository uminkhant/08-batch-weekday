class Lion{
	public String publicName;
	 String defaultName;
	 protected String protectedName;
	 private String privateName;
}