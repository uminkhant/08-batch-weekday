import pkgOne.Cat;
class Main{
	
	public static void main(String[] args) {
		Cat l = new Cat("Susan");
		//l.publicName = "pub";
		//l.defaultName = "defualt";
		//l.protectedName = "protected";
		//l.privateName = "private";

		
	}
}