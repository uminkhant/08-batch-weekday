package pkgOne;

public final class Cat{
	public final String PUBLICNAME;
	 String defaultName;
	 protected String protectedName;
	 private String privateName;

	 public Cat(String name){
	 	PUBLICNAME = name;
	 }

	 final void show(){
	 	class localInner{}
	 }

	 class NestedTest{}

}