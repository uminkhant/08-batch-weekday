package pkgOne;

public class Student{

	private String name;
	private byte age;

	public Student(String name,byte age){
		this.name = name;
		this.age = age;
	}

	public void showStudentDetails(){
		System.out.println("Name :"+name+"\tAge :"+age);
	}

}