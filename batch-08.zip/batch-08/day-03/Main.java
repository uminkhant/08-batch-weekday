import java.util.Scanner;
import pkgOne.Student;
import pkgTwo.StudentService;

class Main{
	static Scanner sc ;
	static StudentService service;
	public static void main(String[] names) {
			sc = new Scanner(System.in);
			service = new StudentService(3);
			showGreeting("Welcome");
			//Student s = getStudent();
			service.setStudent(getStudent(),0);
			service.setStudent(getStudent(),1);
			service.setStudent(getStudent(),2);

	}

	static void showGreeting(String message){
		System.out.println();
		System.out.println("==========================================");
		System.out.println("    =========== "+message+" ===========");
		System.out.println("==========================================");
		System.out.println();
	}

	static Student getStudent(){
		System.out.println("Please type student age !");
		byte age = sc.nextByte();
		System.out.println("Please type Student name !");
		String name = sc.next();
		return new Student(name,age);

	}
}