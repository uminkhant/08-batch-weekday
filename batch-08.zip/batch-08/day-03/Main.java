import java.util.Scanner;
import pkgOne.Student;
import pkgTwo.StudentService;

class Main{
	static Scanner sc ;
	static StudentService service;

	public static void main(String[] names) {
			sc = new Scanner(System.in);
			service = new StudentService(3);
			
			showGreeting("Welcome");
			
			//set student to student sevice with loop
			service.setStudent(getStudent(),0);
			service.setStudent(getStudent(),1);
			service.setStudent(getStudent(),2);

			int i = getIndexForStudent();
			Student s = service.getStudent(i);

			s.showStudentDetails();

			showGreeting("Bye Bye ");
	}

	static int getIndexForStudent(){
		System.out.println();
		System.out.println("Type index number for student array !");
		return sc.nextInt();
		
	}

	static void showGreeting(String message){
		System.out.println();
		System.out.println("==========================================");
		System.out.println("    =========== "+message+" ===========");
		System.out.println("==========================================");
		System.out.println();
	}

	static Student getStudent(){	
		System.out.println("Please type Student name !");
		String name = sc.next();
		System.out.println("Please type student age !");
		byte age = sc.nextByte();
		return new Student(name,age);

	}

	//show all student from student service array
}



