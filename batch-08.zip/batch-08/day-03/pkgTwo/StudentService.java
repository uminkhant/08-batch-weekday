package pkgTwo;
import pkgOne.Student;

public class StudentService{
	private Student[]students;

	public StudentService(int size){
		students = new Student[size];
	}

	public void setStudent(Student student,int index){
		students[index] = student;
	}

	public Student getStudent(int index){
		return students[index];
	}
}