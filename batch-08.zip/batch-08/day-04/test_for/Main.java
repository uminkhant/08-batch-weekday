char[][]arrays = {{'a','b','c'},{'d','e','f'},{'h','i'}};

void main(){
	for(int x = 0 ; x < arrays.length ; x ++){
		for(int y = 0 ; y < arrays[x].length ; y++){
				System.out.println("Char :"+arrays[x][y]);
			}
		}
}