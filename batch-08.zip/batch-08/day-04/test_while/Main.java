import java.util.Scanner;
class Main{
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Please type value !");
		int val = sc.nextInt();
		System.out.println("Please type counter !");
		int count = sc.nextInt();
		testWhile(count,val);
	}
	static void testDoWhile(){
		int i = 0;		
		do{
			System.out.println("Hello");
			i++;
		}while(i<5);
	}

	static void testWhile(int count,int value){

		while(value < count){
			System.out.println("Counter "+ value);
			value ++;
		}
	}
}