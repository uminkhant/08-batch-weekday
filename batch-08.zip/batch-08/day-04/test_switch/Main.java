import javax.swing.JOptionPane;

// javac --release 21 --enable-preview Main.java
// java --enable-preview Main

	void  main() {
		String name = JOptionPane.showInputDialog("Type Name !");
		String mess = newSwitchWithYield(name);
		JOptionPane.showMessageDialog(null,mess);

		String day = JOptionPane.showInputDialog("Type Day !");
		JOptionPane.showMessageDialog(null,newSwitch(day),"Message show",JOptionPane.INFORMATION_MESSAGE);
	}

	static String newSwitchWithYield(String value){
		return switch(value){
			case "Andrew","William" -> {
				System.out.println("First Message");
				yield "admin";
			}
			default -> {
				System.out.println("Second Message");
				yield "Customer";
			}
		};
	}

	static String newSwitch(String value){
		return switch(value){
			case "Mon","Tue","Wed","Thur","Fri" -> "Word day";
			case "Sat","Sun" -> "Off Day";
			default -> "Other";
		};
	}
	static String withReturn(String day){
			//String s = "";
			switch(day){
			case "Mon":
			case "Tue":
			case "Wed":
			case "Thur":
			case "Fir":
				//s = "Work day";
				return "Work Day";
			case "Sat":
			case "Sun":
				//s = "Off day";
				return "Off Day";
			default:
				return "Other";
			}
		}
	static void withBreak(String name){
		switch(name){
		case "Andrew":
			JOptionPane.showMessageDialog(null,"Hello Andrew");
			break;
		case "William":
			JOptionPane.showMessageDialog(null,"Hello William");
			break;
		default :
			JOptionPane.showMessageDialog(null,"Sir ,type your name again pls !");
			break;
		}		
	}

