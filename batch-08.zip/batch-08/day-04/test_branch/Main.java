
void main(){
	branchStatement();
}


void branchStatement(){
	stop:
	for(int x = 0 ; x < 5 ; x ++){
		
		for(int y = 0; y < 5 ; y ++){
			if(y == 3){
				//break;
				//return;
				continue stop ;
			}
			System.out.print("Inner loop :"+y+"\t");	
		}
		System.out.println("Outer loop :"+x+"\t");
		System.out.println();
	}
	System.out.println("Method");	
}

