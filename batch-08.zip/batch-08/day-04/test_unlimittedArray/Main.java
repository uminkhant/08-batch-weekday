	import java.util.Scanner;

	Scanner sc;
	String []arrays = new String[0];
	void main(){
		 sc = new Scanner(System.in);
		 setName();
		 show();
	}

	void setName(){
		String yes = "";
		do{
			System.out.println("Type name !");
			String name = sc.next();
			insertToArray(name);
			System.out.println("Do you want to add again y/other");
			yes = sc.next();
		}while("y".equals(yes));

	}

	//save to unlimitted array 
	void insertToArray(String name){
		String[]temp = new String[arrays.length+1];
		for(int x = 0 ; x <arrays.length ; x++){
			temp[x] = arrays[x];
		}
		temp[arrays.length] = name;
		arrays = temp ;
	}

	void show(){
		for(String s : arrays){
			System.out.println(s);
		}
	}