
class Student{
	void show(){
		 String local_name ;
		 System.out.println(local_name);
		 local_name = "ssa";
		 
		System.out.println(global_name);
		
	}
}
