import java.util.Scanner;

class Main{

	public static void main(String [] arg){
		Scanner sc = new Scanner(System.in);
		System.out.println("Please type your name !");
		String name = sc.next();
		System.out.println("Please type your age !");
		int age = sc.nextInt();
		System.out.println("Your name is "+name+" and your age is "+age);

		Student st = new Student();
		st.show();
	}


	
}
